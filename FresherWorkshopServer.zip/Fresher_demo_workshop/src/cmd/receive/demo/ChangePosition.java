package cmd.receive.demo;

import bitzero.server.extensions.data.BaseCmd;
import bitzero.server.extensions.data.DataCmd;

import java.nio.ByteBuffer;

public class ChangePosition extends BaseCmd {
    public int x;
    public int y;
    public ChangePosition(DataCmd dataCmd) {
        super(dataCmd);
        unpackData();
    }

    @Override
    public void unpackData() {
        ByteBuffer bf = makeBuffer();
        try {
            // deploy code here
        } catch (Exception e) {
            x = y = 0;
        }
    }
}
