package model;

import util.database.DataModel;

import java.util.HashMap;

public class UserGame extends DataModel {
    public HashMap<Long, Long> listPlayedGame;
    public long lastPlayedGame;

    public UserGame() {
        super();
        listPlayedGame = new HashMap<Long, Long>();
    }
}
