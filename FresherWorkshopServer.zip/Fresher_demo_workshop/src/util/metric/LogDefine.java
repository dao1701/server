package util.metric;


public class LogDefine {
    public static final String CCU = "ccu";
}
