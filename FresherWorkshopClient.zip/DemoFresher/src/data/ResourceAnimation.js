/*
	Auto generate
*/

//id
var resAniId = {
	demoEffect: "demoEffect",
chipu: "chipu",
eff_dice_number: "eff_dice_number",
firework_test: "firework_test"
};

//path
var resAni = {
	demoEffect:"game/animation/effects/landmarkConstruct",
chipu: "game/animation/character/chipu",
eff_dice_number: "game/animation/eff_dice_number",
firework_test: "game/animation/firework_test"
};